package com.korit.post_mini_project_back;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PostMiniProjectBackApplication {

    public static void main(String[] args) {
        SpringApplication.run(PostMiniProjectBackApplication.class, args);
    }

}
